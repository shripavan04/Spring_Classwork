package com.example.day1pah;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day1pahApplicationTests {

	@Test
	void contextLoads() {
	}

}
