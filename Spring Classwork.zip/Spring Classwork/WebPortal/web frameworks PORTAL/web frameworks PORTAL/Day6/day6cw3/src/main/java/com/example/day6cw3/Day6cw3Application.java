package com.example.day6cw3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day6cw3Application {

	public static void main(String[] args) {
		SpringApplication.run(Day6cw3Application.class, args);
	}

}
