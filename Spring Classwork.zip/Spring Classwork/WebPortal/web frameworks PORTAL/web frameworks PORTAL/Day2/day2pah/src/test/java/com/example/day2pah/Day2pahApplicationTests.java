package com.example.day2pah;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day2pahApplicationTests {

	@Test
	void contextLoads() {
	}

}
